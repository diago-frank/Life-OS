package com.lifeos.mobile.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TaskEntity::class,
        NoteEntity::class,
        LifeModuleEntity::class,
        HabitEntity::class,
        ShoppingItemEntity::class,
        WorkShiftEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LifeDatabase : RoomDatabase() {
    abstract fun lifeDao(): LifeDao

    companion object {
        @Volatile private var INSTANCE: LifeDatabase? = null

        fun get(context: Context): LifeDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                LifeDatabase::class.java,
                "life_os.db"
            ).build().also { INSTANCE = it }
        }
    }
}
