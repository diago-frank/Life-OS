package com.lifeos.mobile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lifeos.mobile.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = LifeRepository(LifeDatabase.get(application).lifeDao())
    private val prefs = UserPrefs(application)

    val settings = prefs.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())
    val tasks = repo.tasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val notes = repo.notes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val modules = repo.modules.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val habits = repo.habits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val shopping = repo.shopping.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val workShifts = repo.workShifts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun finishSetup(name: String, theme: String, pin: String) = viewModelScope.launch { prefs.finishSetup(name, theme, pin) }
    fun setTheme(theme: String) = viewModelScope.launch { prefs.setTheme(theme) }
    fun setName(name: String) = viewModelScope.launch { prefs.setName(name) }
    fun setLockEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setLockEnabled(enabled) }
    fun resetSetup() = viewModelScope.launch { prefs.reset() }

    fun addTask(title: String) = viewModelScope.launch { repo.addTask(title) }
    fun toggleTask(task: TaskEntity) = viewModelScope.launch { repo.toggleTask(task) }
    fun deleteTask(task: TaskEntity) = viewModelScope.launch { repo.deleteTask(task) }

    fun addNote(title: String, body: String) = viewModelScope.launch { repo.addNote(title, body) }
    fun deleteNote(note: NoteEntity) = viewModelScope.launch { repo.deleteNote(note) }

    fun setModuleInstalled(id: String, installed: Boolean) = viewModelScope.launch { repo.setModuleInstalled(id, installed) }

    fun addHabit(title: String) = viewModelScope.launch { repo.addHabit(title) }
    fun completeHabit(habit: HabitEntity) = viewModelScope.launch { repo.completeHabit(habit) }
    fun deleteHabit(habit: HabitEntity) = viewModelScope.launch { repo.deleteHabit(habit) }

    fun addShopping(title: String) = viewModelScope.launch { repo.addShopping(title) }
    fun toggleShopping(item: ShoppingItemEntity) = viewModelScope.launch { repo.toggleShopping(item) }
    fun deleteShopping(item: ShoppingItemEntity) = viewModelScope.launch { repo.deleteShopping(item) }

    fun startShift() = viewModelScope.launch { repo.startShift() }
    fun stopShift(shift: WorkShiftEntity) = viewModelScope.launch { repo.stopShift(shift) }
}
