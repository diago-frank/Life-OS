package com.lifeos.mobile.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.lifeDataStore by preferencesDataStore(name = "life_os_prefs")

data class UserSettings(
    val setupDone: Boolean = false,
    val name: String = "",
    val theme: String = "AMOLED",
    val lockEnabled: Boolean = true,
    val pinHash: String = "",
    val pinSalt: String = ""
) {
    val hasPin: Boolean get() = pinHash.isNotBlank() && pinSalt.isNotBlank()
}

class UserPrefs(private val context: Context) {
    private object Keys {
        val setupDone = booleanPreferencesKey("setup_done")
        val name = stringPreferencesKey("name")
        val theme = stringPreferencesKey("theme")
        val lockEnabled = booleanPreferencesKey("lock_enabled")
        val pinHash = stringPreferencesKey("pin_hash")
        val pinSalt = stringPreferencesKey("pin_salt")
    }

    val settings: Flow<UserSettings> = context.lifeDataStore.data.map { p ->
        UserSettings(
            setupDone = p[Keys.setupDone] ?: false,
            name = p[Keys.name] ?: "",
            theme = p[Keys.theme] ?: "AMOLED",
            lockEnabled = p[Keys.lockEnabled] ?: true,
            pinHash = p[Keys.pinHash] ?: "",
            pinSalt = p[Keys.pinSalt] ?: ""
        )
    }

    suspend fun finishSetup(name: String, theme: String, pin: String) {
        context.lifeDataStore.edit {
            it[Keys.name] = name.trim().ifEmpty { "User" }
            it[Keys.theme] = theme
            it[Keys.setupDone] = true
            it[Keys.lockEnabled] = true
            if (pin.length >= 4) {
                val salt = ByteArray(16).also(SecureRandom()::nextBytes)
                val salt64 = Base64.getEncoder().encodeToString(salt)
                it[Keys.pinSalt] = salt64
                it[Keys.pinHash] = hashPin(pin, salt)
            }
        }
    }

    suspend fun setTheme(theme: String) { context.lifeDataStore.edit { it[Keys.theme] = theme } }
    suspend fun setName(name: String) { context.lifeDataStore.edit { it[Keys.name] = name.trim().ifEmpty { "User" } } }
    suspend fun setLockEnabled(enabled: Boolean) { context.lifeDataStore.edit { it[Keys.lockEnabled] = enabled } }
    suspend fun reset() { context.lifeDataStore.edit { it.clear() } }

    companion object {
        fun verifyPin(pin: String, settings: UserSettings): Boolean {
            if (!settings.hasPin) return true
            return try {
                val salt = Base64.getDecoder().decode(settings.pinSalt)
                MessageDigest.isEqual(
                    hashPin(pin, salt).toByteArray(),
                    settings.pinHash.toByteArray()
                )
            } catch (_: Exception) { false }
        }

        private fun hashPin(pin: String, salt: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256")
            digest.update(salt)
            return Base64.getEncoder().encodeToString(digest.digest(pin.toByteArray(Charsets.UTF_8)))
        }
    }
}
