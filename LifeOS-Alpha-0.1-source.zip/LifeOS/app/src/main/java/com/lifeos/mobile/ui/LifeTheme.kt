package com.lifeos.mobile.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Cyan = Color(0xFF24D9FF)
private val Blue = Color(0xFF2F7BFF)
private val AMOLED = Color(0xFF000000)
private val DarkSurface = Color(0xFF0A0D12)
private val DarkCard = Color(0xFF121720)

private val AmoledScheme = darkColorScheme(
    primary = Cyan,
    secondary = Blue,
    background = AMOLED,
    surface = DarkSurface,
    surfaceVariant = DarkCard,
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFFD4D9E3)
)

private val DarkScheme = darkColorScheme(
    primary = Cyan,
    secondary = Blue,
    background = Color(0xFF080B10),
    surface = Color(0xFF10151D),
    surfaceVariant = Color(0xFF171E29),
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF006C85),
    secondary = Color(0xFF345DAB),
    background = Color(0xFFF5F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9EEF5),
    onBackground = Color(0xFF101318),
    onSurface = Color(0xFF101318)
)

@Composable
fun LifeTheme(theme: String, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = when (theme.uppercase()) {
            "LIGHT" -> LightScheme
            "DARK" -> DarkScheme
            else -> AmoledScheme
        },
        content = content
    )
}
