package com.lifeos.mobile.model

data class LifeContext(
    val userName: String,
    val currentScreen: String,
    val openTaskCount: Int
)

data class AIResponse(
    val text: String,
    val action: String? = null
)

interface AIProvider {
    suspend fun sendMessage(message: String, context: LifeContext): AIResponse
}
