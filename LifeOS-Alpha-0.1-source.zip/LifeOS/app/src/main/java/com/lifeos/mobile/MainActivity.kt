package com.lifeos.mobile

import android.app.BatteryManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lifeos.mobile.data.*
import com.lifeos.mobile.model.LifeApp
import com.lifeos.mobile.model.LifeCatalog
import com.lifeos.mobile.ui.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(androidx.compose.ui.platform.ComposeView(this).apply {
            setContent { LifeOSRoot(this@MainActivity) }
        })
    }
}

private enum class LifeScreen {
    HOME, TASKS, NOTES, CALENDAR, ASSISTANT, STORE, SETTINGS,
    WORK, HABITS, SHOPPING, FOCUS
}

@Composable
private fun LifeOSRoot(activity: FragmentActivity, vm: AppViewModel = viewModel()) {
    val settings by vm.settings.collectAsState()
    var booting by remember { mutableStateOf(true) }
    var unlocked by remember(settings.setupDone, settings.lockEnabled) {
        mutableStateOf(!settings.lockEnabled)
    }

    LaunchedEffect(Unit) {
        delay(1500)
        booting = false
    }

    LifeTheme(settings.theme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when {
                booting -> BootScreen()
                !settings.setupDone -> SetupScreen(
                    onFinish = { name, theme, pin -> vm.finishSetup(name, theme, pin) }
                )
                !unlocked && settings.lockEnabled -> LockScreen(
                    activity = activity,
                    settings = settings,
                    onUnlock = { unlocked = true }
                )
                else -> LifeShell(
                    vm = vm,
                    settings = settings,
                    onLock = { if (settings.lockEnabled) unlocked = false }
                )
            }
        }
    }
}

@Composable
private fun BootScreen() {
    val inf = rememberInfiniteTransition(label = "boot")
    val glow by inf.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850), RepeatMode.Reverse),
        label = "glow"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.life_logo),
                contentDescription = "Life OS",
                modifier = Modifier.size(158.dp).clip(RoundedCornerShape(34.dp)).alpha(glow),
                contentScale = ContentScale.Crop
            )
            Spacer(Modifier.height(24.dp))
            Text("LIFE OS", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("Your Life. Your System.", color = Color(0xFF9AB4C7), fontSize = 14.sp)
            Spacer(Modifier.height(36.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(170.dp).height(3.dp).clip(CircleShape),
                color = Color(0xFF24D9FF),
                trackColor = Color(0xFF101820)
            )
            Spacer(Modifier.height(10.dp))
            Text("Starting Life OS...", color = Color(0xFF72808D), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SetupScreen(onFinish: (String, String, String) -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var theme by remember { mutableStateOf("AMOLED") }
    var pin by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(WindowInsets.safeDrawing.asPaddingValues())
            .padding(24.dp)
    ) {
        LinearProgressIndicator(
            progress = { (step + 1) / 5f },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape)
        )
        Spacer(Modifier.height(34.dp))
        when (step) {
            0 -> SetupWelcome()
            1 -> SetupIdentity(name) { name = it }
            2 -> SetupTheme(theme) { theme = it }
            3 -> SetupSecurity(pin) { if (it.length <= 6 && it.all(Char::isDigit)) pin = it }
            else -> SetupReady(name.ifBlank { "User" }, theme)
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (step > 0) {
                OutlinedButton(onClick = { step-- }, modifier = Modifier.weight(1f)) { Text("Zurück") }
            }
            Button(
                onClick = {
                    if (step < 4) step++ else onFinish(name, theme, pin)
                },
                modifier = Modifier.weight(1f),
                enabled = step != 1 || name.isNotBlank()
            ) {
                Text(if (step == 4) "Life OS starten" else "Weiter")
            }
        }
    }
}

@Composable
private fun SetupWelcome() {
    Column {
        Image(
            painterResource(R.drawable.life_logo), "Life OS",
            Modifier.size(96.dp).clip(RoundedCornerShape(26.dp)), contentScale = ContentScale.Crop
        )
        Spacer(Modifier.height(28.dp))
        Text("Welcome to Life OS", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(12.dp))
        Text(
            "Dein zweites Smartphone innerhalb deines Smartphones. Life OS bleibt vollständig innerhalb dieser App und ersetzt weder deinen Android-Homescreen noch den echten Sperrbildschirm.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun SetupIdentity(name: String, onName: (String) -> Unit) {
    Column {
        Text("Wie soll Life OS dich nennen?", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Der Name wird nur lokal für Begrüßungen und den Assistant verwendet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(
            value = name,
            onValueChange = onName,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Name") },
            singleLine = true,
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun SetupTheme(theme: String, onTheme: (String) -> Unit) {
    Column {
        Text("Wähle deinen Stil", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Du kannst das später jederzeit ändern.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        listOf("AMOLED", "DARK", "LIGHT").forEach { item ->
            GlassCard(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                onClick = { onTheme(item) }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == item, onClick = { onTheme(item) })
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Life ${item.lowercase().replaceFirstChar { it.uppercase() }}", fontWeight = FontWeight.SemiBold)
                        Text(
                            when (item) {
                                "AMOLED" -> "Echtes Schwarz, cyanfarbene Akzente"
                                "DARK" -> "Dunkel, weich und elegant"
                                else -> "Hell und klar"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupSecurity(pin: String, onPin: (String) -> Unit) {
    Column {
        Text("Schütze Life OS", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Optional: Lege eine interne PIN fest. Sie sperrt nur Life OS. Die PIN wird nicht im Klartext gespeichert.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = onPin,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("4–6 stellige PIN (optional)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            shape = RoundedCornerShape(20.dp)
        )
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column {
                Text("Privacy by Design", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Berechtigungen werden erst dann angefragt, wenn du eine Funktion wirklich nutzt. Life OS ändert keine Systemeinstellung ohne deine Aktion.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SetupReady(name: String, theme: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Spacer(Modifier.height(30.dp))
        Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(78.dp))
        Spacer(Modifier.height(20.dp))
        Text("Life OS is ready.", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text("Willkommen, $name", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column {
                Text("Theme: $theme", fontWeight = FontWeight.SemiBold)
                Text("Datenbank: lokal auf diesem Gerät", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                Text("Life Store: aktiv", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun LockScreen(activity: FragmentActivity, settings: UserSettings, onUnlock: () -> Unit) {
    val time by rememberClock("HH:mm")
    val date by rememberClock("EEEE, d. MMMM")
    var showPin by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black, Color(0xFF03131B), Color.Black)
                )
            )
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, amount ->
                    if (amount < -25f) {
                        if (settings.hasPin) showPin = true else onUnlock()
                    }
                }
            }
    ) {
        Column(
            Modifier.fillMaxSize().padding(WindowInsets.safeDrawing.asPaddingValues()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(70.dp))
            Text(time, fontSize = 76.sp, fontWeight = FontWeight.Light)
            Text(date.replaceFirstChar { it.uppercase() }, color = Color(0xFFA8B4BF), fontSize = 17.sp)
            Spacer(Modifier.height(22.dp))
            Text("Guten Tag, ${settings.name}", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedButton(onClick = { authenticateBiometric(activity, onUnlock) }) {
                    Icon(Icons.Rounded.Fingerprint, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Biometrie")
                }
            }
            Spacer(Modifier.height(18.dp))
            Icon(Icons.Rounded.KeyboardArrowUp, null, tint = MaterialTheme.colorScheme.primary)
            Text("Nach oben wischen", color = Color(0xFFA8B4BF), fontSize = 13.sp)
            Spacer(Modifier.height(26.dp))
        }

        if (showPin) {
            AlertDialog(
                onDismissRequest = { showPin = false; pin = ""; pinError = false },
                title = { Text("Life OS entsperren") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = pin,
                            onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) { pin = it; pinError = false } },
                            label = { Text("PIN") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            isError = pinError,
                            singleLine = true
                        )
                        if (pinError) Text("PIN ist nicht korrekt.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (UserPrefs.verifyPin(pin, settings)) onUnlock() else pinError = true
                    }) { Text("Entsperren") }
                },
                dismissButton = { TextButton(onClick = { showPin = false }) { Text("Abbrechen") } }
            )
        }
    }
}

private fun authenticateBiometric(activity: FragmentActivity, onSuccess: () -> Unit) {
    val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            super.onAuthenticationSucceeded(result)
            onSuccess()
        }
    })
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Life OS entsperren")
        .setSubtitle("Mit deiner Android-Biometrie bestätigen")
        .setNegativeButtonText("Abbrechen")
        .build()
    prompt.authenticate(info)
}

@Composable
private fun LifeShell(vm: AppViewModel, settings: UserSettings, onLock: () -> Unit) {
    val tasks by vm.tasks.collectAsState()
    val notes by vm.notes.collectAsState()
    val modules by vm.modules.collectAsState()
    val habits by vm.habits.collectAsState()
    val shopping by vm.shopping.collectAsState()
    val shifts by vm.workShifts.collectAsState()
    var screen by remember { mutableStateOf(LifeScreen.HOME) }
    var showDrawer by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }
    val installedIds = modules.filter { it.installed }.map { it.id }.toSet()

    BackHandler(enabled = showDrawer || showControl || showNotifications || screen != LifeScreen.HOME) {
        when {
            showDrawer -> showDrawer = false
            showControl -> showControl = false
            showNotifications -> showNotifications = false
            else -> screen = LifeScreen.HOME
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, amount ->
                    if (change.position.y < 190f && amount > 22f) {
                        if (change.position.x > size.width / 2f) showControl = true else showNotifications = true
                    }
                }
            }
    ) {
        Column(Modifier.fillMaxSize().padding(WindowInsets.safeDrawing.asPaddingValues())) {
            val time by rememberClock("HH:mm")
            val context = LocalContext.current
            LifeStatusBar(
                timeText = time,
                batteryText = rememberBattery(context),
                connectivityText = rememberConnectivity(context)
            )
            Box(Modifier.weight(1f)) {
                when (screen) {
                    LifeScreen.HOME -> HomeScreen(
                        settings = settings,
                        tasks = tasks,
                        installedIds = installedIds,
                        onApp = { app -> screen = appToScreen(app.id) },
                        onDrawer = { showDrawer = true },
                        onControl = { showControl = true },
                        onNotifications = { showNotifications = true }
                    )
                    LifeScreen.TASKS -> TasksScreen(tasks, vm::addTask, vm::toggleTask, vm::deleteTask)
                    LifeScreen.NOTES -> NotesScreen(notes, vm::addNote, vm::deleteNote)
                    LifeScreen.CALENDAR -> CalendarScreen(tasks)
                    LifeScreen.ASSISTANT -> AssistantScreen(
                        installedIds = installedIds,
                        addTask = vm::addTask,
                        navigate = { screen = it }
                    )
                    LifeScreen.STORE -> StoreScreen(installedIds, vm::setModuleInstalled)
                    LifeScreen.SETTINGS -> SettingsScreen(
                        settings,
                        vm::setName,
                        vm::setTheme,
                        vm::setLockEnabled,
                        onLock,
                        vm::resetSetup
                    )
                    LifeScreen.WORK -> WorkScreen(shifts, vm::startShift, vm::stopShift)
                    LifeScreen.HABITS -> HabitsScreen(habits, vm::addHabit, vm::completeHabit, vm::deleteHabit)
                    LifeScreen.SHOPPING -> ShoppingScreen(shopping, vm::addShopping, vm::toggleShopping, vm::deleteShopping)
                    LifeScreen.FOCUS -> FocusScreen()
                }
            }
        }

        if (showDrawer) {
            AppDrawer(
                installedIds = installedIds,
                onClose = { showDrawer = false },
                onOpen = { app -> showDrawer = false; screen = appToScreen(app.id) }
            )
        }
        if (showControl) {
            ControlCenter(settings = settings, onTheme = vm::setTheme, onLock = { showControl = false; onLock() }, onClose = { showControl = false })
        }
        if (showNotifications) {
            NotificationCenter(tasks = tasks, habits = habits, onClose = { showNotifications = false })
        }
    }
}

private fun appToScreen(id: String): LifeScreen = when (id) {
    "tasks" -> LifeScreen.TASKS
    "notes" -> LifeScreen.NOTES
    "calendar" -> LifeScreen.CALENDAR
    "assistant" -> LifeScreen.ASSISTANT
    "store" -> LifeScreen.STORE
    "settings" -> LifeScreen.SETTINGS
    "work" -> LifeScreen.WORK
    "habits" -> LifeScreen.HABITS
    "shopping" -> LifeScreen.SHOPPING
    "focus" -> LifeScreen.FOCUS
    else -> LifeScreen.HOME
}

@Composable
private fun HomeScreen(
    settings: UserSettings,
    tasks: List<TaskEntity>,
    installedIds: Set<String>,
    onApp: (LifeApp) -> Unit,
    onDrawer: () -> Unit,
    onControl: () -> Unit,
    onNotifications: () -> Unit
) {
    val pending = tasks.count { !it.completed }
    val visibleApps = LifeCatalog.core + LifeCatalog.optional.filter { it.id in installedIds }
    Column(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, amount -> if (amount < -28f) onDrawer() }
            }
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Guten Tag,", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                Text(settings.name, fontSize = 30.sp, fontWeight = FontWeight.Black)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalIconButton(onClick = onNotifications) { Icon(Icons.Rounded.Notifications, null) }
                FilledTonalIconButton(onClick = onControl) { Icon(Icons.Rounded.Tune, null) }
            }
        }
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Heute", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("$pending offene Aufgaben", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(
                    Modifier.size(50.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) { Text(pending.toString(), color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.Black) }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Life Apps", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 10.dp)
        ) {
            gridItems(visibleApps, key = { it.id }) { app -> LifeAppTile(app, onClick = { onApp(app) }) }
        }
        Surface(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
        ) {
            Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                DockButton("✓", "Tasks") { onApp(LifeCatalog.core.first { it.id == "tasks" }) }
                DockButton("✎", "Notes") { onApp(LifeCatalog.core.first { it.id == "notes" }) }
                DockButton("◉", "Assistant") { onApp(LifeCatalog.core.first { it.id == "assistant" }) }
                DockButton("⬡", "Store") { onApp(LifeCatalog.core.first { it.id == "store" }) }
            }
        }
    }
}

@Composable
private fun DockButton(icon: String, label: String, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Text(icon, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 9.sp)
    }
}

@Composable
private fun AppDrawer(installedIds: Set<String>, onClose: () -> Unit, onOpen: (LifeApp) -> Unit) {
    val context = LocalContext.current
    val allLife = LifeCatalog.core + LifeCatalog.optional.filter { it.id in installedIds }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background.copy(alpha = 0.98f)) {
        Column(Modifier.padding(WindowInsets.safeDrawing.asPaddingValues()).padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("All Apps", "Swipe up home · install more in Life Store")
                IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null) }
            }
            Spacer(Modifier.height(20.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.heightIn(max = 390.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                gridItems(allLife, key = { it.id }) { app -> LifeAppTile(app, { onOpen(app) }) }
            }
            Spacer(Modifier.height(18.dp))
            Text("Android Apps", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Nur bekannte Apps werden angezeigt, wenn sie installiert sind.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            val androidApps = listOf(
                Triple("Spotify", "com.spotify.music", "♫"),
                Triple("WhatsApp", "com.whatsapp", "W"),
                Triple("YouTube", "com.google.android.youtube", "▶"),
                Triple("Discord", "com.discord", "D")
            ).filter { context.packageManager.getLaunchIntentForPackage(it.second) != null }
            if (androidApps.isEmpty()) {
                Text("Keine der unterstützten Apps gefunden.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    androidApps.forEach { (name, pkg, icon) ->
                        Column(
                            Modifier.width(66.dp).clickable {
                                context.packageManager.getLaunchIntentForPackage(pkg)?.let(context::startActivity)
                            },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                                Text(icon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(name, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TasksScreen(
    tasks: List<TaskEntity>,
    add: (String) -> Unit,
    toggle: (TaskEntity) -> Unit,
    delete: (TaskEntity) -> Unit
) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Tasks", "${tasks.count { !it.completed }} offen · ${tasks.count { it.completed }} erledigt")
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Neue Aufgabe") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            FilledIconButton(onClick = { add(text); text = "" }, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.Add, null) }
        }
        Spacer(Modifier.height(14.dp))
        if (tasks.isEmpty()) EmptyState("Noch keine Aufgaben", "Erstelle deine erste Aufgabe oben.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { task ->
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(task.completed, onCheckedChange = { toggle(task) })
                        Text(task.title, modifier = Modifier.weight(1f), color = if (task.completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                        IconButton(onClick = { delete(task) }) { Icon(Icons.Rounded.DeleteOutline, null) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesScreen(notes: List<NoteEntity>, add: (String, String) -> Unit, delete: (NoteEntity) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            SectionTitle("Life Notes", "${notes.size} Notizen")
            FilledIconButton(onClick = { dialog = true }) { Icon(Icons.Rounded.Add, null) }
        }
        Spacer(Modifier.height(18.dp))
        if (notes.isEmpty()) EmptyState("Deine Gedanken, an einem Ort", "Tippe auf +, um eine Notiz anzulegen.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(notes, key = { it.id }) { note ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(note.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            if (note.body.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(note.body, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 5, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        IconButton(onClick = { delete(note) }) { Icon(Icons.Rounded.DeleteOutline, null) }
                    }
                }
            }
        }
    }
    if (dialog) NoteDialog(onDismiss = { dialog = false }, onSave = { t, b -> add(t, b); dialog = false })
}

@Composable
private fun NoteDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Neue Notiz") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Titel") }, singleLine = true)
                OutlinedTextField(body, { body = it }, label = { Text("Text") }, minLines = 4)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(title, body) }) { Text("Speichern") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

@Composable
private fun CalendarScreen(tasks: List<TaskEntity>) {
    val today = LocalDate.now()
    val dateText = today.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL).withLocale(Locale.GERMAN))
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Calendar", "$dateText")
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column {
                Text(today.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.GERMAN).replaceFirstChar { it.uppercase() }, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(today.year.toString(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Text("Heute: ${tasks.count { !it.completed }} offene Aufgaben", color = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Tagesübersicht", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (tasks.none { !it.completed }) Text("Für heute ist nichts offen.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks.filter { !it.completed }, key = { it.id }) { task ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        AccentDot(); Spacer(Modifier.width(12.dp)); Text(task.title)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Eigene Termine und Android-Kalendersynchronisierung werden in der nächsten Ausbaustufe ergänzt.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun AssistantScreen(installedIds: Set<String>, addTask: (String) -> Unit, navigate: (LifeScreen) -> Unit) {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Hallo. Ich bin dein lokaler Life Assistant. Ich kann Apps öffnen und Aufgaben anlegen.")) }
    fun process(raw: String) {
        val q = raw.trim()
        if (q.isBlank()) return
        val lower = q.lowercase(Locale.GERMAN)
        val response = when {
            lower.startsWith("erstelle aufgabe") || lower.startsWith("neue aufgabe") -> {
                val title = q.substringAfter("aufgabe", "").trim().trimStart(':')
                if (title.isBlank()) "Nenne mir nach „Aufgabe“ noch einen Titel." else { addTask(title); "✓ Aufgabe „$title“ erstellt." }
            }
            "öffne tasks" in lower || "öffne aufgaben" in lower -> { navigate(LifeScreen.TASKS); "Öffne Life Tasks." }
            "öffne notizen" in lower || "öffne notes" in lower -> { navigate(LifeScreen.NOTES); "Öffne Life Notes." }
            "öffne kalender" in lower -> { navigate(LifeScreen.CALENDAR); "Öffne Life Calendar." }
            "öffne store" in lower -> { navigate(LifeScreen.STORE); "Öffne Life Store." }
            "öffne einkauf" in lower && "shopping" in installedIds -> { navigate(LifeScreen.SHOPPING); "Öffne Life Shopping." }
            else -> "In dieser Alpha arbeite ich lokal. Versuch z. B. „Erstelle Aufgabe Müll rausbringen“ oder „Öffne Tasks“."
        }
        messages = messages + "Du: $q" + "Life: $response"
        input = ""
    }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Assistant", "Lokal · Provider-Schnittstelle vorbereitet")
        Spacer(Modifier.height(14.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { m ->
                Surface(shape = RoundedCornerShape(18.dp), color = if (m.startsWith("Du:")) MaterialTheme.colorScheme.primary.copy(alpha = 0.13f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)) {
                    Text(m.removePrefix("Du: ").removePrefix("Life: "), Modifier.padding(14.dp))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Frag Life Assistant…") }, shape = RoundedCornerShape(20.dp), singleLine = true)
            FilledIconButton(onClick = { process(input) }, modifier = Modifier.size(56.dp)) { Icon(Icons.Rounded.Send, null) }
        }
    }
}

@Composable
private fun StoreScreen(installedIds: Set<String>, setInstalled: (String, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Store", "Apps für dein internes Life OS")
        Spacer(Modifier.height(8.dp))
        Text("Installierte Life Apps bleiben innerhalb von Life OS. Sie verändern dein Android-System nicht.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(LifeCatalog.optional, key = { it.id }) { app ->
                val available = app.id in setOf("work", "habits", "shopping", "focus")
                val installed = app.id in installedIds
                Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.74f)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                            Text(app.icon, color = MaterialTheme.colorScheme.primary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(app.name, fontWeight = FontWeight.Bold)
                            Text(app.description, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 2)
                            Text(app.category, color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                        }
                        if (available) {
                            Button(onClick = { setInstalled(app.id, !installed) }) {
                                Text(if (installed) "Entfernen" else "Installieren")
                            }
                        } else {
                            AssistChip(onClick = {}, label = { Text("Coming Soon") }, enabled = false)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: UserSettings,
    setName: (String) -> Unit,
    setTheme: (String) -> Unit,
    setLock: (Boolean) -> Unit,
    onLockNow: () -> Unit,
    reset: () -> Unit
) {
    var editName by remember(settings.name) { mutableStateOf(settings.name) }
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        SectionTitle("Life Settings", "System, Darstellung und Datenschutz")
        Spacer(Modifier.height(18.dp))
        SettingsGroup("Profil") {
            OutlinedTextField(editName, { editName = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = { setName(editName) }) { Text("Name speichern") }
        }
        SettingsGroup("Appearance") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("AMOLED", "DARK", "LIGHT").forEach { t ->
                    FilterChip(selected = settings.theme == t, onClick = { setTheme(t) }, label = { Text(t) })
                }
            }
        }
        SettingsGroup("Sicherheit") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Life OS Sperre", fontWeight = FontWeight.Medium); Text("Sperrt nur diese App", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
                Switch(checked = settings.lockEnabled, onCheckedChange = setLock)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onLockNow, enabled = settings.lockEnabled) { Text("Jetzt sperren") }
        }
        SettingsGroup("Privacy Center") {
            PrivacyLine("Lokale Datenbank", "Aktiv")
            PrivacyLine("Notification Access", "Nicht angefragt")
            PrivacyLine("Kalenderzugriff", "Nicht angefragt")
            PrivacyLine("Medienzugriff", "Nicht angefragt")
            Text("Life OS fragt Berechtigungen erst bei Bedarf an.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        SettingsGroup("Daten") {
            Text("Tasks, Notes, Life Store Apps, Habits, Shopping und Work werden lokal gespeichert.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmReset = true }) { Text("Ersteinrichtung zurücksetzen") }
        }
        Spacer(Modifier.height(18.dp))
        Text("Life OS Alpha 0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Setup zurücksetzen?") },
            text = { Text("Deine Tasks und Notizen bleiben erhalten; Profil- und Setup-Einstellungen werden zurückgesetzt.") },
            confirmButton = { TextButton(onClick = { reset(); confirmReset = false }) { Text("Zurücksetzen") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Abbrechen") } }
        )
    }
}

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    Spacer(Modifier.height(8.dp))
    Text(title, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), content = content)
    }
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun PrivacyLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HabitsScreen(habits: List<HabitEntity>, add: (String) -> Unit, complete: (HabitEntity) -> Unit, delete: (HabitEntity) -> Unit) {
    var input by remember { mutableStateOf("") }
    val today = LocalDate.now().toString()
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Habits", "Baue Routinen, nicht Druck")
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Neue Gewohnheit") }, singleLine = true, shape = RoundedCornerShape(18.dp))
            FilledIconButton(onClick = { add(input); input = "" }, Modifier.size(56.dp)) { Icon(Icons.Rounded.Add, null) }
        }
        Spacer(Modifier.height(14.dp))
        if (habits.isEmpty()) EmptyState("Noch keine Gewohnheiten", "Zum Beispiel: 10 Minuten spazieren.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(habits, key = { it.id }) { h ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(h.title, fontWeight = FontWeight.Bold)
                            Text("Streak: ${h.streak}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        FilledTonalIconButton(onClick = { complete(h) }, enabled = h.lastDoneDay != today) {
                            Icon(Icons.Rounded.Check, null)
                        }
                        IconButton(onClick = { delete(h) }) { Icon(Icons.Rounded.DeleteOutline, null) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ShoppingScreen(itemsList: List<ShoppingItemEntity>, add: (String) -> Unit, toggle: (ShoppingItemEntity) -> Unit, delete: (ShoppingItemEntity) -> Unit) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Shopping", "${itemsList.count { !it.checked }} noch offen")
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Artikel hinzufügen") }, singleLine = true, shape = RoundedCornerShape(18.dp))
            FilledIconButton(onClick = { add(input); input = "" }, Modifier.size(56.dp)) { Icon(Icons.Rounded.Add, null) }
        }
        Spacer(Modifier.height(14.dp))
        if (itemsList.isEmpty()) EmptyState("Einkaufsliste ist leer", "Füge oben deinen ersten Artikel hinzu.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(itemsList, key = { it.id }) { item ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(item.checked, onCheckedChange = { toggle(item) })
                        Text(item.title, Modifier.weight(1f))
                        IconButton(onClick = { delete(item) }) { Icon(Icons.Rounded.DeleteOutline, null) }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkScreen(shifts: List<WorkShiftEntity>, start: () -> Unit, stop: (WorkShiftEntity) -> Unit) {
    val active = shifts.firstOrNull { it.endAt == null }
    val totalMs = shifts.filter { it.endAt != null }.sumOf { (it.endAt ?: it.startAt) - it.startAt }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        SectionTitle("Life Work", "Schichten und Arbeitszeit lokal erfassen")
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(if (active == null) "Nicht eingestempelt" else "Schicht läuft", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.height(6.dp))
                Text("Gespeichert: ${formatDuration(totalMs)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(14.dp))
                Button(onClick = { if (active == null) start() else stop(active) }) {
                    Icon(if (active == null) Icons.Rounded.PlayArrow else Icons.Rounded.Stop, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (active == null) "Schicht starten" else "Schicht beenden")
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Letzte Schichten", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (shifts.isEmpty()) Text("Noch keine Schicht erfasst.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(shifts.take(12), key = { it.id }) { s ->
                Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatDateTime(s.startAt))
                        Text(if (s.endAt == null) "läuft" else formatDuration(s.endAt - s.startAt), color = if (s.endAt == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun FocusScreen() {
    var remaining by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    LaunchedEffect(running, remaining) {
        if (running && remaining > 0) {
            delay(1000)
            remaining--
        } else if (remaining == 0) running = false
    }
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SectionTitle("Life Focus", "Einfacher Fokus-Timer")
        Spacer(Modifier.height(70.dp))
        Text(String.format(Locale.ROOT, "%02d:%02d", remaining / 60, remaining % 60), fontSize = 72.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { running = !running }) { Icon(if (running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(if (running) "Pause" else "Start") }
            OutlinedButton(onClick = { running = false; remaining = 25 * 60 }) { Text("Reset") }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 25, 45).forEach { min -> AssistChip(onClick = { running = false; remaining = min * 60 }, label = { Text("$min min") }) }
        }
    }
}

@Composable
private fun ControlCenter(settings: UserSettings, onTheme: (String) -> Unit, onLock: () -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    Surface(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).padding(top = 80.dp),
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("Control Center", "Systemaktionen bleiben Android-konform")
                IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null) }
            }
            Spacer(Modifier.height(20.dp))
            LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(240.dp)) {
                item { ControlTile("Internet", Icons.Rounded.Wifi) { context.safeStart(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) } }
                item { ControlTile("Bluetooth", Icons.Rounded.Bluetooth) { context.safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } }
                item { ControlTile("Display", Icons.Rounded.Brightness6) { context.safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } }
                item { ControlTile("Sound", Icons.Rounded.VolumeUp) { context.safeStart(Intent(Settings.ACTION_SOUND_SETTINGS)) } }
            }
            Spacer(Modifier.height(18.dp))
            Text("Life Theme", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("AMOLED", "DARK", "LIGHT").forEach { t -> FilterChip(selected = settings.theme == t, onClick = { onTheme(t) }, label = { Text(t) }) }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onLock, enabled = settings.lockEnabled, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Rounded.Lock, null); Spacer(Modifier.width(8.dp)); Text("Life OS sperren")
            }
            Spacer(Modifier.height(12.dp))
            Text("Taschenlampe und direkte System-Schalter werden erst ergänzt, wenn die jeweilige Android-Berechtigung sauber angefragt wird.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ControlTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun NotificationCenter(tasks: List<TaskEntity>, habits: List<HabitEntity>, onClose: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)).padding(top = 80.dp),
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("Notifications", "Life OS interne Hinweise")
                IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, null) }
            }
            Spacer(Modifier.height(16.dp))
            val pending = tasks.filter { !it.completed }.take(5)
            if (pending.isEmpty() && habits.isEmpty()) EmptyState("Alles ruhig", "Keine internen Hinweise.")
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(pending, key = { "t${it.id}" }) { t -> NotificationCard("TASKS", t.title, "Offene Aufgabe") }
                items(habits.take(3), key = { "h${it.id}" }) { h -> NotificationCard("HABITS", h.title, "Streak ${h.streak}") }
            }
        }
    }
}

@Composable
private fun NotificationCard(source: String, title: String, subtitle: String) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(source, color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun rememberClock(pattern: String): State<String> {
    val state = remember { mutableStateOf(SimpleDateFormat(pattern, Locale.GERMAN).format(Date())) }
    LaunchedEffect(pattern) {
        while (true) {
            state.value = SimpleDateFormat(pattern, Locale.GERMAN).format(Date())
            delay(30_000)
        }
    }
    return state
}

@Composable
private fun rememberBattery(context: Context): String = remember {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    if (pct in 0..100) "$pct%" else ""
}

@Composable
private fun rememberConnectivity(context: Context): String = remember {
    try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobil"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "LAN"
            else -> ""
        }
    } catch (_: Exception) { "" }
}

private fun Context.safeStart(intent: Intent) {
    try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
}

private fun formatDuration(ms: Long): String {
    val mins = (ms / 60_000).coerceAtLeast(0)
    return "${mins / 60}h ${mins % 60}m"
}

private fun formatDateTime(ms: Long): String = SimpleDateFormat("dd.MM. HH:mm", Locale.GERMAN).format(Date(ms))
