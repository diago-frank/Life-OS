package com.lifeos.mobile.model

data class LifeApp(
    val id: String,
    val name: String,
    val icon: String,
    val description: String,
    val category: String,
    val builtIn: Boolean = false
)

object LifeCatalog {
    val core = listOf(
        LifeApp("tasks", "Life Tasks", "✓", "Aufgaben, Prioritäten und Erinnerungen", "Produktivität", true),
        LifeApp("notes", "Life Notes", "✎", "Notizen und Checklisten", "Produktivität", true),
        LifeApp("calendar", "Life Calendar", "▦", "Kalender und Tagesübersicht", "Organisation", true),
        LifeApp("assistant", "Life Assistant", "◉", "Lokaler Assistent und Schnellaktionen", "System", true),
        LifeApp("store", "Life Store", "⬡", "Apps für Life OS installieren", "System", true),
        LifeApp("settings", "Settings", "⚙", "Life OS anpassen", "System", true)
    )

    val optional = listOf(
        LifeApp("work", "Life Work", "⌚", "Schichten, Arbeitszeiten und Überstunden", "Arbeit"),
        LifeApp("habits", "Life Habits", "◎", "Gewohnheiten, Streaks und Routinen", "Lifestyle"),
        LifeApp("shopping", "Life Shopping", "🛒", "Einkaufslisten mit Kategorien", "Organisation"),
        LifeApp("focus", "Life Focus", "◐", "Fokus-Sessions und Pomodoro", "Produktivität"),
        LifeApp("goals", "Life Goals", "◆", "Ziele in konkrete Schritte zerlegen", "Lifestyle"),
        LifeApp("lists", "Life Lists", "☷", "Packlisten, Checklisten und Vorlagen", "Organisation"),
        LifeApp("vault", "Life Vault", "◇", "Geschützter Bereich für private Einträge", "Sicherheit"),
        LifeApp("subscriptions", "Life Subscriptions", "€", "Abos und wiederkehrende Kosten", "Finanzen")
    )
}
