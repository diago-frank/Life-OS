package com.lifeos.mobile.data

import java.time.LocalDate
import kotlinx.coroutines.flow.Flow

class LifeRepository(private val dao: LifeDao) {
    val tasks: Flow<List<TaskEntity>> = dao.observeTasks()
    val notes: Flow<List<NoteEntity>> = dao.observeNotes()
    val modules: Flow<List<LifeModuleEntity>> = dao.observeModules()
    val habits: Flow<List<HabitEntity>> = dao.observeHabits()
    val shopping: Flow<List<ShoppingItemEntity>> = dao.observeShopping()
    val workShifts: Flow<List<WorkShiftEntity>> = dao.observeWorkShifts()

    suspend fun addTask(title: String) {
        val cleaned = title.trim()
        if (cleaned.isNotEmpty()) dao.addTask(TaskEntity(title = cleaned))
    }
    suspend fun toggleTask(task: TaskEntity) = dao.updateTask(task.copy(completed = !task.completed))
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task.id)

    suspend fun addNote(title: String, body: String) {
        val cleanTitle = title.trim()
        val cleanBody = body.trim()
        if (cleanTitle.isNotEmpty() || cleanBody.isNotEmpty()) {
            dao.addNote(NoteEntity(title = cleanTitle.ifEmpty { "Neue Notiz" }, body = cleanBody))
        }
    }
    suspend fun deleteNote(note: NoteEntity) = dao.deleteNote(note.id)

    suspend fun setModuleInstalled(id: String, installed: Boolean) {
        dao.upsertModule(LifeModuleEntity(id, installed, if (installed) System.currentTimeMillis() else null))
    }

    suspend fun addHabit(title: String) {
        val clean = title.trim()
        if (clean.isNotEmpty()) dao.addHabit(HabitEntity(title = clean))
    }
    suspend fun completeHabit(habit: HabitEntity) {
        val today = LocalDate.now().toString()
        if (habit.lastDoneDay != today) {
            dao.updateHabit(habit.copy(streak = habit.streak + 1, lastDoneDay = today))
        }
    }
    suspend fun deleteHabit(habit: HabitEntity) = dao.deleteHabit(habit.id)

    suspend fun addShopping(title: String) {
        val clean = title.trim()
        if (clean.isNotEmpty()) dao.addShopping(ShoppingItemEntity(title = clean))
    }
    suspend fun toggleShopping(item: ShoppingItemEntity) = dao.updateShopping(item.copy(checked = !item.checked))
    suspend fun deleteShopping(item: ShoppingItemEntity) = dao.deleteShopping(item.id)

    suspend fun startShift() = dao.addShift(WorkShiftEntity(startAt = System.currentTimeMillis()))
    suspend fun stopShift(shift: WorkShiftEntity) {
        if (shift.endAt == null) dao.updateShift(shift.copy(endAt = System.currentTimeMillis()))
    }
}
