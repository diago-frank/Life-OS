package com.lifeos.mobile.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LifeDao {
    @Query("SELECT * FROM tasks ORDER BY completed ASC, createdAt DESC")
    fun observeTasks(): Flow<List<TaskEntity>>
    @Insert suspend fun addTask(task: TaskEntity)
    @Update suspend fun updateTask(task: TaskEntity)
    @Query("DELETE FROM tasks WHERE id = :id") suspend fun deleteTask(id: Long)

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeNotes(): Flow<List<NoteEntity>>
    @Insert suspend fun addNote(note: NoteEntity)
    @Query("DELETE FROM notes WHERE id = :id") suspend fun deleteNote(id: Long)

    @Query("SELECT * FROM life_modules")
    fun observeModules(): Flow<List<LifeModuleEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertModule(module: LifeModuleEntity)

    @Query("SELECT * FROM habits ORDER BY id DESC")
    fun observeHabits(): Flow<List<HabitEntity>>
    @Insert suspend fun addHabit(habit: HabitEntity)
    @Update suspend fun updateHabit(habit: HabitEntity)
    @Query("DELETE FROM habits WHERE id = :id") suspend fun deleteHabit(id: Long)

    @Query("SELECT * FROM shopping ORDER BY checked ASC, createdAt DESC")
    fun observeShopping(): Flow<List<ShoppingItemEntity>>
    @Insert suspend fun addShopping(item: ShoppingItemEntity)
    @Update suspend fun updateShopping(item: ShoppingItemEntity)
    @Query("DELETE FROM shopping WHERE id = :id") suspend fun deleteShopping(id: Long)

    @Query("SELECT * FROM work_shifts ORDER BY startAt DESC")
    fun observeWorkShifts(): Flow<List<WorkShiftEntity>>
    @Insert suspend fun addShift(shift: WorkShiftEntity)
    @Update suspend fun updateShift(shift: WorkShiftEntity)
}
