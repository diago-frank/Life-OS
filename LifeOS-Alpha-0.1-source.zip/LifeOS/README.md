# Life OS — Alpha 0.1

Life OS is an Android application that simulates a second smartphone environment **inside the app**. It does not register as a launcher and does not replace Android, One UI, the system lock screen, or persistent system navigation.

## Implemented in this alpha

- Animated Life OS boot sequence using the supplied Life OS logo
- First-run setup: name, theme, optional 4–6 digit Life OS PIN
- Internal Life OS lock screen
  - swipe-to-unlock
  - salted SHA-256 PIN verification (PIN is not stored as plaintext)
  - Android BiometricPrompt support
- Life OS homescreen and dock
- Internal status bar using real battery/network data when available
- App drawer
  - Life apps
  - launch Spotify, WhatsApp, YouTube, Discord when installed
- Control Center
  - Internet panel
  - Bluetooth settings
  - Display settings
  - Sound settings
  - Life theme switching
  - internal Life OS lock
- Internal notification center
- Room-backed local database
- DataStore-backed setup/profile/theme/security settings
- Life Tasks
- Life Notes
- Life Calendar day overview
- Life Assistant Alpha with local commands and a provider-agnostic `AIProvider` interface
- Life Settings + Privacy Center
- Life Store with functional internal module install/uninstall
- Installable Life Store modules in this build:
  - Life Work (shift clock + stored shift history)
  - Life Habits (persistent habits + streaks)
  - Life Shopping (persistent shopping list)
  - Life Focus (focus timer)
- Planned store entries are visibly marked **Coming Soon**, not presented as finished.

## Build

The project targets Android API 35 and uses Kotlin + Jetpack Compose.

Requirements:
- JDK 17
- Android SDK 35
- Gradle 8.10.2

Build locally:

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

A GitHub Actions workflow is included at `.github/workflows/android.yml`. Pushing the project to a GitHub repository automatically produces a downloadable `LifeOS-alpha-apk` artifact.

## Security / Android boundaries

Life OS intentionally does not:
- declare HOME/launcher intent filters
- replace the real Android lock screen
- silently toggle restricted system settings
- silently install Android APKs
- collect hidden analytics

Life Store in Alpha 0.1 installs **internal Life OS modules** into the Life OS drawer. A future remote catalog can add Android APK delivery, but Android's Package Installer confirmation must remain in control.
