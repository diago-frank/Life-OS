# Life OS – Android APK Alpha

Life OS is a full-screen Android app that behaves like a self-contained mini operating system without replacing Samsung One UI or Android.

## Alpha features
- Boot screen and lock screen
- Custom Life OS home screen and app drawer
- Simulated status bar and control center
- Life Browser (WebView)
- Life Files (Android document picker)
- Life Notes with local persistence
- Life Tasks with local persistence
- Life Calculator
- Life Clock
- Life Settings with accent themes
- Life Store for internal modules
- Life AI / Mia local command interface
- Gallery picker and camera launcher
- Music picker/player
- Voice recorder

## Safety / scope
This APK does not replace the Android launcher, lock screen, bootloader, or Samsung system UI. Android-protected settings remain controlled by Android and are opened through official system settings panels.

## Build
GitHub Actions builds a debug APK on pull requests.
