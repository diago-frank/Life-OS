package com.lifeos.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 200;
    private static final int REQ_IMAGE = 201;
    private static final int REQ_CAMERA = 202;
    private static final int REQ_RECORD_AUDIO = 203;

    private final Handler handler = new Handler();
    private android.content.SharedPreferences prefs;
    private LinearLayout currentPage;
    private int bgColor = Color.rgb(7, 9, 13);
    private int panelColor = Color.rgb(20, 23, 30);
    private int softColor = Color.rgb(37, 40, 48);
    private int textColor = Color.WHITE;
    private int mutedColor = Color.rgb(165, 170, 180);
    private int accentColor = Color.rgb(218, 178, 86);
    private MediaPlayer mediaPlayer;
    private MediaRecorder mediaRecorder;
    private File recordingFile;
    private ImageView galleryPreview;
    private ImageView cameraPreview;
    private TextView musicState;
    private TextView recorderState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("life_os", MODE_PRIVATE);
        applySavedAccent();
        makeImmersive();
        if (prefs.getBoolean("skip_boot", false)) showLock(); else showBoot();
    }

    private void makeImmersive() {
        Window w = getWindow();
        w.setStatusBarColor(bgColor);
        w.setNavigationBarColor(bgColor);
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void applySavedAccent() {
        String accent = prefs == null ? "gold" : prefs.getString("accent", "gold");
        if ("blue".equals(accent)) accentColor = Color.rgb(88, 164, 255);
        else if ("violet".equals(accent)) accentColor = Color.rgb(165, 110, 255);
        else accentColor = Color.rgb(218, 178, 86);
    }

    private GradientDrawable box(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setBackground(box(softColor, 16));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        return b;
    }

    private Button accentButton(String label) {
        Button b = button(label);
        b.setTextColor(Color.BLACK);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(box(accentColor, 16));
        return b;
    }

    private View spacer(int heightDp) {
        Space s = new Space(this);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(heightDp)));
        return s;
    }

    private LinearLayout pageRoot() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.setPadding(dp(18), dp(18), dp(18), dp(20));
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        currentPage = root;
        return root;
    }

    private void showBoot() {
        LinearLayout root = pageRoot();
        root.setGravity(Gravity.CENTER);
        TextView brand = text("LIFE OS", 40, textColor, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView sub = text("Private mobile environment", 13, accentColor, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(spacer(34));
        TextView status = text("System wird gestartet …", 14, mutedColor, false);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        handler.postDelayed(this::showLock, 1500);
    }

    private void showLock() {
        LinearLayout root = pageRoot();
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(spacer(80));
        LocalDateTime now = LocalDateTime.now();
        TextView time = text(now.format(DateTimeFormatter.ofPattern("HH:mm")), 64, textColor, true);
        time.setGravity(Gravity.CENTER);
        root.addView(time, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        String date = now.format(DateTimeFormatter.ofPattern("EEEE, dd. MMMM", Locale.GERMAN));
        TextView day = text(date, 18, mutedColor, false);
        day.setGravity(Gravity.CENTER);
        root.addView(day, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(spacer(40));

        LinearLayout notice = new LinearLayout(this);
        notice.setOrientation(LinearLayout.VERTICAL);
        notice.setPadding(dp(18), dp(16), dp(18), dp(16));
        notice.setBackground(box(panelColor, 18));
        notice.addView(text("Life OS", 14, accentColor, true));
        notice.addView(text("Dein privater Bereich ist bereit.", 16, textColor, false));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.setMargins(0, 0, 0, dp(40));
        root.addView(notice, np);

        Button unlock = accentButton("Entsperren");
        unlock.setOnClickListener(v -> showHome());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        root.addView(unlock, bp);
        root.addView(spacer(14));
        TextView hint = text("Life OS sperrt nur diese App – nicht dein Android-Gerät.", 12, mutedColor, false);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private LinearLayout statusBar() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = text(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), 13, textColor, true);
        row.addView(l, new LinearLayout.LayoutParams(0, dp(34), 1f));
        TextView r = text("Wi‑Fi   5G   82%", 12, mutedColor, false);
        r.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(r, new LinearLayout.LayoutParams(0, dp(34), 1f));
        return row;
    }

    private void showHome() {
        LinearLayout root = pageRoot();
        root.addView(statusBar());

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Life OS", 30, textColor, true));
        titles.addView(text("Alpha 0.1 · sicher innerhalb Android", 12, mutedColor, false));
        titleRow.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button control = button("Control");
        control.setOnClickListener(v -> showControlCenter());
        titleRow.addView(control, new LinearLayout.LayoutParams(dp(104), dp(46)));
        root.addView(titleRow);
        root.addView(spacer(18));

        LinearLayout widget = new LinearLayout(this);
        widget.setOrientation(LinearLayout.VERTICAL);
        widget.setPadding(dp(18), dp(16), dp(18), dp(16));
        widget.setBackground(box(panelColor, 22));
        widget.addView(text("Guten Tag", 13, accentColor, true));
        widget.addView(text("Willkommen in deinem Life OS", 21, textColor, true));
        widget.addView(text("Tippe auf eine App oder öffne Mia.", 13, mutedColor, false));
        root.addView(widget, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(spacer(18));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        addAppTile(grid, "Browser", "◉");
        addAppTile(grid, "Dateien", "▣");
        addAppTile(grid, "Notizen", "✎");
        addAppTile(grid, "Aufgaben", "✓");
        addAppTile(grid, "Galerie", "▧");
        addAppTile(grid, "Kamera", "◎");
        addAppTile(grid, "Musik", "♫");
        addAppTile(grid, "Uhr", "◷");
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setPadding(dp(8), dp(8), dp(8), dp(8));
        dock.setBackground(box(panelColor, 22));
        addDock(dock, "Apps", this::showAppDrawer);
        addDock(dock, "Mia", () -> openApp("Mia"));
        addDock(dock, "Store", () -> openApp("Store"));
        addDock(dock, "Einstellungen", () -> openApp("Einstellungen"));
        root.addView(dock, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));
        setContentView(root);
    }

    private void addAppTile(GridLayout grid, String name, String symbol) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(4), dp(8), dp(4), dp(8));
        TextView icon = text(symbol, 28, accentColor, true);
        icon.setGravity(Gravity.CENTER);
        TextView label = text(name, 12, textColor, true);
        label.setGravity(Gravity.CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        tile.addView(label, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));
        tile.setOnClickListener(v -> openApp(name));
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(88);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        grid.addView(tile, gp);
    }

    private void addDock(LinearLayout row, String label, Runnable action) {
        Button b = button(label);
        b.setTextSize(11);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        row.addView(b, p);
    }

    private void showAppDrawer() {
        LinearLayout content = pageRoot();
        addAppHeader(content, "Alle Apps");
        EditText search = new EditText(this);
        search.setHint("Apps durchsuchen");
        search.setHintTextColor(mutedColor);
        search.setTextColor(textColor);
        search.setSingleLine(true);
        search.setBackground(box(panelColor, 16));
        search.setPadding(dp(14), 0, dp(14), 0);
        content.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        content.addView(spacer(12));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        List<String> apps = Arrays.asList("Browser", "Dateien", "Notizen", "Aufgaben", "Galerie", "Kamera", "Musik", "Rekorder", "Rechner", "Uhr", "Store", "Mia", "Einstellungen", "Wetter");
        for (String app : apps) addDrawerTile(grid, app);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(grid);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(content);
    }

    private void addDrawerTile(GridLayout grid, String app) {
        Button b = button(app);
        b.setOnClickListener(v -> openApp(app));
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(62);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        grid.addView(b, gp);
    }

    private void addAppHeader(LinearLayout root, String title) {
        root.addView(statusBar());
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("‹ Home");
        back.setOnClickListener(v -> showHome());
        row.addView(back, new LinearLayout.LayoutParams(dp(96), dp(44)));
        TextView t = text(title, 22, textColor, true);
        t.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(row);
        root.addView(spacer(14));
    }

    private void openApp(String name) {
        switch (name) {
            case "Browser": showBrowser(); break;
            case "Dateien": showFiles(); break;
            case "Notizen": showNotes(); break;
            case "Aufgaben": showTasks(); break;
            case "Galerie": showGallery(); break;
            case "Kamera": showCamera(); break;
            case "Musik": showMusic(); break;
            case "Rekorder": showRecorder(); break;
            case "Rechner": showCalculator(); break;
            case "Uhr": showClock(); break;
            case "Store": showStore(); break;
            case "Mia": showMia(); break;
            case "Einstellungen": showSettings(); break;
            case "Wetter": showWeather(); break;
            default: toast("App noch nicht verfügbar");
        }
    }

    private void showControlCenter() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Control Center");
        TextView title = text("Schnelleinstellungen", 26, textColor, true);
        root.addView(title);
        root.addView(text("Geschützte Android-Funktionen werden über die offiziellen Systemseiten geöffnet.", 13, mutedColor, false));
        root.addView(spacer(16));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        addControl(grid, "WLAN / Internet", () -> {
            try {
                if (Build.VERSION.SDK_INT >= 29) startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                else startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
            } catch (Exception e) { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
        });
        addControl(grid, "Bluetooth", () -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)));
        addControl(grid, "Anzeige", () -> startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));
        addControl(grid, "Ton", () -> startActivity(new Intent(Settings.ACTION_SOUND_SETTINGS)));
        addControl(grid, "Akku", () -> startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        addControl(grid, "Hotspot", () -> startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)));
        root.addView(grid);
        root.addView(spacer(20));
        TextView own = text("Life OS", 18, textColor, true);
        root.addView(own);
        Switch immersive = new Switch(this);
        immersive.setText("Immersiver Vollbildmodus");
        immersive.setTextColor(textColor);
        immersive.setChecked(true);
        immersive.setOnCheckedChangeListener((b, checked) -> {
            if (checked) makeImmersive();
            else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        });
        root.addView(immersive);
        setContentView(root);
    }

    private void addControl(GridLayout grid, String label, Runnable action) {
        Button b = button(label);
        b.setOnClickListener(v -> action.run());
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(72);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(5), dp(5), dp(5), dp(5));
        grid.addView(b, gp);
    }

    private void showBrowser() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Browser");
        LinearLayout addressRow = new LinearLayout(this);
        addressRow.setOrientation(LinearLayout.HORIZONTAL);
        EditText address = new EditText(this);
        address.setSingleLine(true);
        address.setText("https://www.google.com");
        address.setTextColor(textColor);
        address.setHintTextColor(mutedColor);
        address.setBackground(box(panelColor, 14));
        address.setPadding(dp(12), 0, dp(12), 0);
        Button go = accentButton("Los");
        addressRow.addView(address, new LinearLayout.LayoutParams(0, dp(50), 1f));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(dp(70), dp(50));
        gp.setMargins(dp(8), 0, 0, 0);
        addressRow.addView(go, gp);
        root.addView(addressRow);
        root.addView(spacer(8));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.getSettings().setJavaScriptEnabled(true);
        go.setOnClickListener(v -> {
            String u = address.getText().toString().trim();
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://www.google.com/search?q=" + Uri.encode(u);
            web.loadUrl(u);
        });
        web.loadUrl(address.getText().toString());
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void showFiles() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Files");
        root.addView(text("Dateien", 28, textColor, true));
        root.addView(text("Life OS nutzt den sicheren Android-Dateiauswahldialog. Dadurch bekommt die App nur Zugriff auf Dateien, die du selbst auswählst.", 13, mutedColor, false));
        root.addView(spacer(18));
        addWideAction(root, "Datei öffnen", () -> openDocument("*/*", 0));
        addWideAction(root, "Bild auswählen", () -> openDocument("image/*", REQ_IMAGE));
        addWideAction(root, "Musik auswählen", () -> openDocument("audio/*", REQ_AUDIO));
        addWideAction(root, "Android Speicher-Einstellungen", () -> startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
        setContentView(root);
    }

    private void addWideAction(LinearLayout root, String label, Runnable action) {
        Button b = button(label);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        p.setMargins(0, 0, 0, dp(10));
        root.addView(b, p);
    }

    private void openDocument(String type, int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(type);
        startActivityForResult(i, requestCode);
    }

    private void showNotes() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Notes");
        EditText note = new EditText(this);
        note.setText(prefs.getString("note", ""));
        note.setHint("Schreib deine Notiz …");
        note.setTextColor(textColor);
        note.setHintTextColor(mutedColor);
        note.setGravity(Gravity.TOP | Gravity.START);
        note.setPadding(dp(16), dp(16), dp(16), dp(16));
        note.setBackground(box(panelColor, 18));
        root.addView(note, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(spacer(10));
        Button save = accentButton("Notiz speichern");
        save.setOnClickListener(v -> {
            prefs.edit().putString("note", note.getText().toString()).apply();
            toast("Notiz gespeichert");
        });
        root.addView(save, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        setContentView(root);
    }

    private void showTasks() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Tasks");
        EditText input = new EditText(this);
        input.setHint("Neue Aufgabe");
        input.setHintTextColor(mutedColor);
        input.setTextColor(textColor);
        input.setBackground(box(panelColor, 14));
        input.setPadding(dp(12), 0, dp(12), 0);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        root.addView(spacer(8));
        Button add = accentButton("Aufgabe hinzufügen");
        root.addView(add, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        root.addView(spacer(14));
        LinearLayout taskList = new LinearLayout(this);
        taskList.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(taskList);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        renderTasks(taskList);
        add.setOnClickListener(v -> {
            String s = input.getText().toString().trim();
            if (s.isEmpty()) return;
            List<String> tasks = loadTasks();
            tasks.add(s);
            saveTasks(tasks);
            input.setText("");
            renderTasks(taskList);
        });
        setContentView(root);
    }

    private List<String> loadTasks() {
        String raw = prefs.getString("tasks", "");
        ArrayList<String> list = new ArrayList<>();
        if (!raw.trim().isEmpty()) list.addAll(Arrays.asList(raw.split("\\n")));
        return list;
    }

    private void saveTasks(List<String> list) {
        prefs.edit().putString("tasks", String.join("\n", list)).apply();
    }

    private void renderTasks(LinearLayout taskList) {
        taskList.removeAllViews();
        List<String> tasks = loadTasks();
        if (tasks.isEmpty()) {
            taskList.addView(text("Noch keine Aufgaben.", 14, mutedColor, false));
            return;
        }
        for (int i = 0; i < tasks.size(); i++) {
            final int index = i;
            CheckBox cb = new CheckBox(this);
            cb.setText(tasks.get(i));
            cb.setTextColor(textColor);
            cb.setPadding(dp(8), dp(8), dp(8), dp(8));
            cb.setBackground(box(panelColor, 14));
            cb.setOnCheckedChangeListener((buttonView, checked) -> {
                if (checked) {
                    handler.postDelayed(() -> {
                        List<String> updated = loadTasks();
                        if (index < updated.size()) updated.remove(index);
                        saveTasks(updated);
                        renderTasks(taskList);
                    }, 250);
                }
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56));
            p.setMargins(0, 0, 0, dp(8));
            taskList.addView(cb, p);
        }
    }

    private void showGallery() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Gallery");
        galleryPreview = new ImageView(this);
        galleryPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        galleryPreview.setBackground(box(panelColor, 18));
        root.addView(galleryPreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(spacer(10));
        Button pick = accentButton("Bild auswählen");
        pick.setOnClickListener(v -> openDocument("image/*", REQ_IMAGE));
        root.addView(pick, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        setContentView(root);
    }

    private void showCamera() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Camera");
        cameraPreview = new ImageView(this);
        cameraPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        cameraPreview.setBackground(box(panelColor, 18));
        root.addView(cameraPreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(spacer(10));
        Button take = accentButton("Kamera öffnen");
        take.setOnClickListener(v -> {
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (i.resolveActivity(getPackageManager()) != null) startActivityForResult(i, REQ_CAMERA);
            else toast("Keine Kamera-App gefunden");
        });
        root.addView(take, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        setContentView(root);
    }

    private void showMusic() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Music");
        TextView icon = text("♫", 72, accentColor, true);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120)));
        musicState = text("Noch kein Titel ausgewählt", 16, textColor, true);
        musicState.setGravity(Gravity.CENTER);
        root.addView(musicState, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        addWideAction(root, "Musik auswählen und abspielen", () -> openDocument("audio/*", REQ_AUDIO));
        addWideAction(root, "Pause / Fortsetzen", () -> {
            if (mediaPlayer == null) return;
            if (mediaPlayer.isPlaying()) { mediaPlayer.pause(); musicState.setText("Pausiert"); }
            else { mediaPlayer.start(); musicState.setText("Wiedergabe läuft"); }
        });
        setContentView(root);
    }

    private void showRecorder() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Recorder");
        recorderState = text("Bereit für eine Aufnahme", 18, textColor, true);
        recorderState.setGravity(Gravity.CENTER);
        root.addView(spacer(40));
        root.addView(recorderState, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(80)));
        Button start = accentButton("Aufnahme starten");
        start.setOnClickListener(v -> startRecording());
        root.addView(start, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        root.addView(spacer(10));
        Button stop = button("Aufnahme stoppen");
        stop.setOnClickListener(v -> stopRecording());
        root.addView(stop, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        setContentView(root);
    }

    private void startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }
        try {
            recordingFile = new File(getCacheDir(), "life-recording.m4a");
            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mediaRecorder.setOutputFile(recordingFile.getAbsolutePath());
            mediaRecorder.prepare();
            mediaRecorder.start();
            if (recorderState != null) recorderState.setText("Aufnahme läuft …");
        } catch (Exception e) {
            toast("Aufnahme konnte nicht gestartet werden");
        }
    }

    private void stopRecording() {
        if (mediaRecorder == null) return;
        try { mediaRecorder.stop(); } catch (Exception ignored) {}
        mediaRecorder.release();
        mediaRecorder = null;
        if (recorderState != null && recordingFile != null) recorderState.setText("Gespeichert: " + recordingFile.getName());
    }

    private void showCalculator() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Calculator");
        EditText display = new EditText(this);
        display.setTextColor(textColor);
        display.setTextSize(28);
        display.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        display.setSingleLine(true);
        display.setBackground(box(panelColor, 18));
        display.setPadding(dp(14), 0, dp(14), 0);
        root.addView(display, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(82)));
        root.addView(spacer(12));
        GridLayout pad = new GridLayout(this);
        pad.setColumnCount(4);
        String[] keys = {"7","8","9","÷","4","5","6","×","1","2","3","-","C","0","=","+"};
        for (String k : keys) {
            Button b = button(k);
            if ("=".equals(k)) { b.setTextColor(Color.BLACK); b.setBackground(box(accentColor, 16)); }
            b.setOnClickListener(v -> {
                if ("C".equals(k)) display.setText("");
                else if ("=".equals(k)) display.setText(calculate(display.getText().toString()));
                else display.append(k);
            });
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0; gp.height = dp(64);
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(4), dp(4), dp(4), dp(4));
            pad.addView(b, gp);
        }
        root.addView(pad);
        setContentView(root);
    }

    private String calculate(String raw) {
        try {
            String s = raw.replace("×", "*").replace("÷", "/");
            char op = 0; int pos = -1;
            for (int i = 1; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '+' || c == '-' || c == '*' || c == '/') { op = c; pos = i; break; }
            }
            if (pos < 0) return s;
            double a = Double.parseDouble(s.substring(0, pos));
            double b = Double.parseDouble(s.substring(pos + 1));
            double out;
            if (op == '+') out = a + b;
            else if (op == '-') out = a - b;
            else if (op == '*') out = a * b;
            else out = a / b;
            if (Math.rint(out) == out) return String.valueOf((long) out);
            return String.valueOf(out);
        } catch (Exception e) { return "Fehler"; }
    }

    private void showClock() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Clock");
        TextView now = text(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), 48, textColor, true);
        now.setGravity(Gravity.CENTER);
        root.addView(spacer(40));
        root.addView(now, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
        Runnable updater = new Runnable() {
            @Override public void run() {
                if (now.getWindowToken() != null) {
                    now.setText(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.post(updater);
        root.addView(text("Timer-Schnellstart", 17, textColor, true));
        root.addView(spacer(8));
        addWideAction(root, "1 Minute", () -> startSimpleTimer(60, now));
        addWideAction(root, "5 Minuten", () -> startSimpleTimer(300, now));
        setContentView(root);
    }

    private void startSimpleTimer(int seconds, TextView label) {
        final int[] left = {seconds};
        Runnable r = new Runnable() {
            @Override public void run() {
                if (label.getWindowToken() == null) return;
                if (left[0] <= 0) { label.setText("Fertig!"); toast("Life Timer beendet"); return; }
                int m = left[0] / 60, s = left[0] % 60;
                label.setText(String.format(Locale.GERMAN, "%02d:%02d", m, s));
                left[0]--;
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(r);
    }

    private void showStore() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Store");
        root.addView(text("Interne Module", 26, textColor, true));
        root.addView(text("In dieser Alpha installiert der Store keine fremden APKs. Er verwaltet sichere Life-OS-Module innerhalb der App.", 13, mutedColor, false));
        root.addView(spacer(14));
        addModule(root, "Focus Mode", "Minimaler Homescreen für konzentriertes Arbeiten", "module_focus");
        addModule(root, "Neon Theme", "Zusätzlicher violetter Premium-Akzent", "module_neon");
        addModule(root, "Developer Panel", "Zeigt technische Alpha-Informationen", "module_dev");
        setContentView(root);
    }

    private void addModule(LinearLayout root, String name, String description, String key) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(box(panelColor, 18));
        card.addView(text(name, 18, textColor, true));
        card.addView(text(description, 13, mutedColor, false));
        Button install = button(prefs.getBoolean(key, false) ? "Installiert ✓" : "Installieren");
        install.setOnClickListener(v -> {
            boolean next = !prefs.getBoolean(key, false);
            prefs.edit().putBoolean(key, next).apply();
            install.setText(next ? "Installiert ✓" : "Installieren");
            toast(next ? name + " installiert" : name + " entfernt");
        });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        ip.setMargins(0, dp(10), 0, 0);
        card.addView(install, ip);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, dp(10));
        root.addView(card, p);
    }

    private void showMia() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life AI · Mia");
        TextView answer = text("Mia: Ich kann Life OS lokal bedienen. Versuch z. B. „öffne Browser“, „öffne Notizen“, „wie spät ist es“ oder „öffne Einstellungen“.", 15, textColor, false);
        answer.setPadding(dp(16), dp(16), dp(16), dp(16));
        answer.setBackground(box(panelColor, 18));
        root.addView(answer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(spacer(10));
        EditText input = new EditText(this);
        input.setHint("Nachricht an Mia …");
        input.setHintTextColor(mutedColor);
        input.setTextColor(textColor);
        input.setBackground(box(panelColor, 14));
        input.setPadding(dp(12), 0, dp(12), 0);
        root.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        root.addView(spacer(8));
        Button send = accentButton("Senden");
        send.setOnClickListener(v -> handleMia(input.getText().toString(), answer));
        root.addView(send, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        setContentView(root);
    }

    private void handleMia(String input, TextView answer) {
        String q = input.toLowerCase(Locale.GERMAN).trim();
        if (q.contains("browser")) openApp("Browser");
        else if (q.contains("notiz")) openApp("Notizen");
        else if (q.contains("aufgabe")) openApp("Aufgaben");
        else if (q.contains("store")) openApp("Store");
        else if (q.contains("einstellung")) openApp("Einstellungen");
        else if (q.contains("musik")) openApp("Musik");
        else if (q.contains("uhr") || q.contains("spät") || q.contains("zeit"))
            answer.setText("Mia: Es ist " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + " Uhr.");
        else if (q.contains("hallo") || q.contains("hi")) answer.setText("Mia: Hallo! Life OS läuft und ich bin bereit.");
        else answer.setText("Mia: In Alpha 0.1 arbeite ich offline mit Life-OS-Befehlen. Eine Verbindung zu deinem eigenen Mia-Server kann später ergänzt werden.");
    }

    private void showSettings() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Settings");
        root.addView(text("Darstellung", 22, textColor, true));
        root.addView(spacer(8));
        addAccentSetting(root, "Gold", "gold");
        addAccentSetting(root, "Blau", "blue");
        addAccentSetting(root, "Violett", "violet");
        root.addView(spacer(16));
        Switch skip = new Switch(this);
        skip.setText("Bootanimation überspringen");
        skip.setTextColor(textColor);
        skip.setChecked(prefs.getBoolean("skip_boot", false));
        skip.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean("skip_boot", checked).apply());
        root.addView(skip);
        root.addView(spacer(18));
        root.addView(text("System", 22, textColor, true));
        root.addView(text("Life OS Alpha 0.1\nPaket: com.lifeos.app\nAndroid bleibt vollständig erhalten. Life OS läuft nur innerhalb dieser APK.", 14, mutedColor, false));
        root.addView(spacer(12));
        addWideAction(root, "Android App-Info", () -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        setContentView(root);
    }

    private void addAccentSetting(LinearLayout root, String label, String value) {
        Button b = button("Akzent: " + label);
        b.setOnClickListener(v -> {
            prefs.edit().putString("accent", value).apply();
            applySavedAccent();
            toast("Design gespeichert");
            showSettings();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        p.setMargins(0, 0, 0, dp(8));
        root.addView(b, p);
    }

    private void showWeather() {
        LinearLayout root = pageRoot();
        addAppHeader(root, "Life Weather");
        TextView icon = text("☁", 72, accentColor, true);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(110)));
        TextView info = text("Wetter-Modul vorbereitet", 22, textColor, true);
        info.setGravity(Gravity.CENTER);
        root.addView(info);
        TextView desc = text("Für echte Wetterdaten braucht Life OS später einen Wetteranbieter oder eine eigene Server-Schnittstelle. Die Alpha fragt deshalb noch keine Standortdaten ab.", 14, mutedColor, false);
        desc.setGravity(Gravity.CENTER);
        root.addView(desc);
        root.addView(spacer(20));
        addWideAction(root, "Wetter im Browser öffnen", () -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=wetter"));
            startActivity(i);
        });
        setContentView(root);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        try {
            if (requestCode == REQ_AUDIO && data.getData() != null) {
                if (mediaPlayer != null) mediaPlayer.release();
                mediaPlayer = new MediaPlayer();
                mediaPlayer.setDataSource(this, data.getData());
                mediaPlayer.prepare();
                mediaPlayer.start();
                if (musicState != null) musicState.setText("Wiedergabe läuft");
            } else if (requestCode == REQ_IMAGE && data.getData() != null) {
                if (galleryPreview != null) galleryPreview.setImageURI(data.getData());
            } else if (requestCode == REQ_CAMERA && data.getExtras() != null) {
                Object bitmap = data.getExtras().get("data");
                if (cameraPreview != null && bitmap instanceof android.graphics.Bitmap)
                    cameraPreview.setImageBitmap((android.graphics.Bitmap) bitmap);
            }
        } catch (Exception e) {
            toast("Datei konnte nicht geöffnet werden");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startRecording();
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (mediaPlayer != null) { mediaPlayer.release(); mediaPlayer = null; }
        if (mediaRecorder != null) { try { mediaRecorder.release(); } catch (Exception ignored) {} mediaRecorder = null; }
        super.onDestroy();
    }
}
