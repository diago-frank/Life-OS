# Life OS alpha: no custom ProGuard rules yet.
